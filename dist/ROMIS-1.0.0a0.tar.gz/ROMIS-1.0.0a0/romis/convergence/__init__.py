from romis.convergence.criterion import Criterion
from romis.convergence.displacement import Criterion_Displacement
