# RIGID

Geometry optimization of rigid molecules on rigid surfaces.

TODO

Author: Siegfried Kaidisch (siegfried.kaidisch(at)uni-graz.at)

## Quickstart

    pip install rigid

## Installation
    
From PyPI:

    pip install rigid

From GitHub:

    git clone https://github.com/siegfriedkaidisch/RIGID
    cd RIGID
    pip install .

## Usage
    
TO DO

## Known issues

For a list of known issues please see the [issues page on GitHub](https://github.com/siegfriedkaidisch/RIGID/issues), otherwise please open a new issue.