from .GDWAS import GDWAS
