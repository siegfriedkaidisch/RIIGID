from riigid.convergence.criterion import Criterion
from riigid.convergence.displacement import Criterion_Displacement
