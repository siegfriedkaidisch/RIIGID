from riigid.optimizer.Deprecated_GDWAS import Deprecated_GDWAS
from riigid.optimizer.GDWAS import GDWAS
from riigid.optimizer.optimizer import Optimizer
